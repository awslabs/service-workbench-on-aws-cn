# Addon for Environment Types Management UI

This package adds UI for Workspace Type management (i.e., UI for importing workspace types based on AWS Service Catalog Products)
