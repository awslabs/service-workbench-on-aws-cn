# @aws-ee/key-pair-mgmt-ui

This package contains user interface entities, stores and react component for key pairs management feature
