# Addon for performing user id upgrade

The purpose of this add-on is to apply the necessary upgrade tasks needed to support replacing the way the user identity presented from a json object to an opaque id string.

## npm packages

- @aws-ee/user-id-upgrade-post-deployment
